# place any of your own overrides here.
# see bombsquad_server for details on what you can override
# examples (uncomment to use):
# config['partyName'] = '🥶༺❄🅑︎🅔︎🅛︎🅐︎🅛︎❄سيرفر عربي ༻🥶'
# config['sessionType'] = 'teams'
# config['maxPartySize'] = 26
# config['port'] = 43209
# config['playlistCode'] = 490260
