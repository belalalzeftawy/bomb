adminHashes = ['pb-IF5RUEQoIg==', 'pb-IF4CUFcvCA==', 'pb-IF4HUFYSXQ==']
vipHashes = []
banlist = {'pb-IF4HU0chJA=='}
topperslist = []
effectCustomers = {}
customlist = {}
ownerHashes = ['pb-IF5VU1URJA==','pb-IF4XUXYREQ==']
surroundingObjectEffect = []
sparkEffect = ['pb-IF5VU1URJA==','pb-IF4XUXYREQ==']
smokeEffect = []
scorchEffect = [] 
distortionEffect = []
glowEffect = []
iceEffect=[]
slimeEffect = []
metalEffect = []
dragonHashes = []
customtagHashes=[]

#donot change the order of the list
#to enable/disable commands and effects for top 5 players goto settings.py