import bs
import bsInternal
import bsUI
import bsUtils
from bsUtils import *
import random

Messages = ['Rank 1 will get Admin','Rank 2 will get Vip','Rank 5 will get Tag','Join the Discord Server to get your rank reward','Contact the owners on Discord Server']

DelayLength = 125 #Should Be In Seconds

def messager():
	random_msg = random.choice(Messages)
	bsInternal._chatMessage(random_msg)
	return

timer = bs.Timer(DelayLength * 1000, messager, timeType='real', repeat=True)
