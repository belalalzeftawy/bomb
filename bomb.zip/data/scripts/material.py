import bs
import random
import bsUtils
import math
import bsVector
import bsSpaz
import bsGame
import bsMap

class PortalFactory(object):
    def __init__(self):
        self.puasModel = bs.getModel('flash')
        
        self.puasTex = bs.getTexture('bg')
        
        self.cubeMaterial = bs.Material()
        self.stickyMaterial = bs.Material()
        
        self.cubeMaterial.addActions(
            conditions=((('weAreYoungerThan',100),'or',('theyAreYoungerThan',100)),
                        'and',('theyHaveMaterial',bs.getSharedObject('objectMaterial'))),
            actions=(('modifyNodeCollision','collide',False)))

        self.cubeMaterial.addActions(
            conditions=('theyHaveMaterial',bs.getSharedObject('pickupMaterial')),
            actions=(('modifyPartCollision','useNodeCollide',False)))
            

        self.cubeMaterial.addActions(
            conditions=('theyHaveMaterial',bs.getSharedObject('pickupMaterial')),
            actions=(('modifyPartCollision','useNodeCollide',False)))
            
            
        self.impactBlastMaterial = bs.Material()
        self.impactBlastMaterial.addActions(
            conditions=(('weAreOlderThan',200),
                        'and',('theyAreOlderThan',200),
                        'and',('evalColliding',),
                        'and',(('theyHaveMaterial',bs.getSharedObject('footingMaterial')),
                               'or',('theyHaveMaterial',bs.getSharedObject('objectMaterial')))),
            actions=(('message','ourNode','atConnect',ImpactMessage())))

class SplatMessage(object):
    pass
            

class ImpactMessage(object):
    """ impact bomb touched something """
    pass     

class Puas(object):
    def __init__(self,position=(0,0,0),velocity = (0,0,0),owner = None,sourcePlayer = None,expire = True,hit = True):
    
        object.__init__(self)
        
        factory = self.getFactory()

        self.node = bs.newNode('prop',
                               delegate=self,
                               attrs={'position':position,
                                      'velocity':velocity,
                                      'model':factory.puasModel,
                                      'lightModel':factory.puasModel,
                                      'body':'crate',
                                      'modelScale':0.5,
                                      'shadowSize':0.2,                                       
                                      'colorTexture':factory.puasTex,
                                      'reflection':'soft',
                                      'reflectionScale':[0.23],
                                      'materials':(factory.impactBlastMaterial, bs.getSharedObject('footingMaterial'), bs.getSharedObject('objectMaterial'))})
                                      
        # if no owner was provided, use an unconnected node ref
        if owner is None: owner = bs.Node(None)

        # the node this came from
        self.hit = hit
        self.owner = owner
        self.expire = expire
                                      
    @classmethod
    def getFactory(cls):
        """
        Returns a shared bs.FlagFactory object, creating it if necessary.
        """
        activity = bs.getActivity()
        try: return activity._sharedPortalFactory

        except Exception:
            f = activity._sharedPortalFactory = PortalFactory()
            return f

            
    def handleMessage(self,m):
        if isinstance(m,bs.DieMessage):
            if self.node.exists():
                self.node.delete()
        if isinstance(m,bs.OutOfBoundsMessage):
            if self.node.exists():
                self.node.delete()
        if isinstance(m,ImpactMessage):
            if self.hit == True:
                bs.Blast(position = self.node.position,hitType = 'punch',blastRadius = 1).autoRetain()
            if self.expire == True:
                if self.node.exists():
                    self._lifeTime = bs.Timer(20000,bs.WeakCall(self.animBR))
                    self._clrTime = bs.Timer(20310,bs.WeakCall(self.clrBR))
            
    def animBR(self):
        if self.node.exists():
            bs.animate(self.node,"modelScale",{0:1,200:0})
        
    def clrBR(self):
        if self.node.exists():
            self.node.delete()
            
class Lego(object):
    def __init__(self,position = (0,1,0),num = int(random.random()*3),colorNum = int(random.random()*3),velocity = (0,0,0)):
    
        #i am too lazy, to use factory
        factory = self.getFactory()
        self.node = bs.newNode('prop',
                            delegate=self,
                            attrs={'position':position,
                                    'model':bs.getModel('agentHead') if num == 1 else bs.getModel('agentHead') if num == 2 else bs.getModel('agentHead'),
                                    'lightModel':bs.getModel('agentHead') if num == 1 else bs.getModel('agentHead') if num == 2 else bs.getModel('agentHead'),
                                    'body':'landMine',
                                    'velocity':velocity,
                                    'modelScale':0.8,
                                    'bodyScale':0.8,
                                    'shadowSize':0.5,
                                    'colorTexture':bs.getTexture('yellow') if colorNum == 1 else bs.getTexture('blue') if colorNum == 2 else bs.getTexture('red'),
                                    'reflection':'powerup',
                                    'reflectionScale':[1.0],
                                    'materials':(factory.legoMaterial,bs.getSharedObject('footingMaterial'), bs.getSharedObject('objectMaterial'))})
                                    
    @classmethod
    def getFactory(cls):
        activity = bs.getActivity()
        try: return activity._sharedPortalFactory
        except Exception:
            f = activity._sharedPortalFactory = PortalFactory()
            return f
                                    
    def handleMessage(self,m):
        if isinstance(m,bs.DieMessage):
            if self.node.exists():
                self.node.delete()
        elif isinstance(m,bs.OutOfBoundsMessage):
            self.node.handleMessage(bs.DieMessage())
        elif isinstance(m,bs.PickedUpMessage):
            self.node.sticky = False
        elif isinstance(m,bs.DroppedMessage):
            self.node.sticky = False
        elif isinstance(m,LegoConnect):
            self.node.sticky = True
        elif isinstance(m,FuckFuckFuckFuckingLego):
            self.node.sticky = False
            node = bs.getCollisionInfo('opposingNode')
            node.handleMessage("impulse",node.position[0],node.position[1],node.position[2],
                                    node.velocity[0],3,node.velocity[2],
                                    45,45,0,0,node.velocity[0],3,node.velocity[2])
        elif isinstance(m,bs.HitMessage):
            
            m.srcNode.handleMessage("impulse",m.pos[0],m.pos[1],m.pos[2],
                                    m.velocity[0],m.velocity[1],m.velocity[2],
                                    m.magnitude,m.velocityMagnitude,m.radius,0,m.velocity[0],m.velocity[1],m.velocity[2])
    
class ShockWave(object):
    def __init__(self,position = (0,1,0),radius=2,speed = 200):
        self.position = position
        
        self.shockWaveMaterial = bs.Material()
        self.shockWaveMaterial.addActions(conditions=(('theyHaveMaterial', bs.getSharedObject('playerMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedSpaz)))
        self.shockWaveMaterial.addActions(conditions=(('theyHaveMaterial', bs.getSharedObject('objectMaterial')),'and',('theyDontHaveMaterial', bs.getSharedObject('playerMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedObj)))
        self.radius = radius

        self.node = bs.newNode('region',
                       attrs={'position':(self.position[0],self.position[1],self.position[2]),
                              'scale':(0.1,0.1,0.1),
                              'type':'sphere',
                              'color':(10,0,10),
                              'materials':[self.shockWaveMaterial]})
                              
        self.visualRadius = bs.newNode('shield',attrs={'position':self.position,'color':(1.05,0.05,1.1),'radius':0.1})
        
        bsUtils.animate(self.visualRadius,"radius",{0:0,speed:self.radius*2})
        bsUtils.animateArray(self.node,"scale",3,{0:(0,0,0),speed:(self.radius,self.radius,self.radius)},True)
        
        bs.gameTimer(speed+1000,self.node.delete)
        bs.gameTimer(speed+1, self.visualRadius.delete)
        
        
    def touchedSpaz(self):
        node = bs.getCollisionInfo('opposingNode')
        
        s = node.getDelegate()._punchPowerScale
        node.getDelegate()._punchPowerScale -= 0.3
        def re():
            node.getDelegate()._punchPowerScale = s
        bs.gameTimer(2000,re)
        
        node.handleMessage("impulse",node.position[0],node.position[1],node.position[2],
                                    -node.velocity[0],-node.velocity[1],-node.velocity[2],
                                    200,200,0,0,-node.velocity[0],-node.velocity[1],-node.velocity[2])
        flash = bs.newNode("flash",
                                   attrs={'position':node.position,
                                          'size':0.7,
                                          'color':(0,0.4+random.random(),1)})
                                          
        explosion = bs.newNode("explosion",
                               attrs={'position':node.position,
                                      'velocity':(node.velocity[0],max(-1.0,node.velocity[1]),node.velocity[2]),
                                      'radius':0.4,
                                      'big':True,
                                      'color':(0.3,0.3,1)})
        bs.gameTimer(400,explosion.delete)
                                          
        bs.emitBGDynamics(position=node.position,count=20,scale=0.5,spread=0.5,chunkType='spark')
        bs.gameTimer(60,flash.delete)
    
    def touchedObj(self):
        node = bs.getCollisionInfo('opposingNode')

        node.handleMessage("impulse",node.position[0]+random.uniform(-2,2),node.position[1]+random.uniform(-2,2),node.position[2]+random.uniform(-2,2),
                                    -node.velocity[0]+random.uniform(-2,2),-node.velocity[1]+random.uniform(-2,2),-node.velocity[2]+random.uniform(-2,2),
                                    100,100,0,0,-node.velocity[0]+random.uniform(-2,2),-node.velocity[1]+random.uniform(-2,2),-node.velocity[2]+random.uniform(-2,2))
        flash = bs.newNode("flash",
                                   attrs={'position':node.position,
                                          'size':0.4,
                                          'color':(0,0.4+random.random(),1)})
                                          
        explosion = bs.newNode("explosion",
                               attrs={'position':node.position,
                                      'velocity':(node.velocity[0],max(-1.0,node.velocity[1]),node.velocity[2]),
                                      'radius':0.4,
                                      'big':True,
                                      'color':(0.3,0.3,1)})
        bs.gameTimer(400,explosion.delete)
                                          
        bs.emitBGDynamics(position=node.position,count=20,scale=0.5,spread=0.5,chunkType='spark')
        bs.gameTimer(60,flash.delete)        
        
    def delete(self):
        self.node.delete()
        self.visualRadius.delete()
        
class BlackHole(object):
    def __init__(self,position = (0,1,0),autoExpand = True,scale = 1,doNotRandomize = False,infinity = False,owner = None):
        self.shields = []
        
        self.position = (position[0]-2+random.random()*4,position[1]+random.random()*2,position[2]-2+random.random()*4) if not doNotRandomize else position
        self.scale = scale
        self.suckObjects = []
        
        self.owner = owner
        
        self.blackHoleMaterial = bs.Material()
        self.suckMaterial = bs.Material()
        self.blackHoleMaterial.addActions(conditions=(('theyDontHaveMaterial', bs.getSharedObject('objectMaterial')),'and',('theyHaveMaterial', bs.getSharedObject('playerMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedSpaz)))
                                                      
        self.blackHoleMaterial.addActions(conditions=(('theyDontHaveMaterial', bs.getSharedObject('playerMaterial')),'and',('theyHaveMaterial', bs.getSharedObject('objectMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedObj)))
                                                  
        self.suckMaterial.addActions(conditions=(('theyHaveMaterial', bs.getSharedObject('objectMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedObjSuck)))
                                                  
                                                  
        self.node = bs.newNode('region',
                       attrs={'position':(self.position[0],self.position[1],self.position[2]),
                              'scale':(scale,scale,scale),
                              'type':'sphere',
                              'materials':[self.blackHoleMaterial]})
                              
        self.suckRadius = bs.newNode('region',
                       attrs={'position':(self.position[0],self.position[1],self.position[2]),
                              'scale':(scale,scale,scale),
                              'type':'sphere',
                              'materials':[self.suckMaterial]})
                              
        def dist():
            bs.emitBGDynamics(position=self.position,emitType='distortion',spread=6,count = 100)
            if self.node.exists():
                bs.gameTimer(1000,dist)
                
        dist()
        
        if not infinity:
            self._dieTimer = bs.Timer(25000,bs.WeakCall(self.explode))
        bsUtils.animateArray(self.node,"scale",3,{0:(0,0,0),300:(self.scale,self.scale,self.scale)},True)
        bsUtils.animateArray(self.suckRadius,"scale",3,{0:(0,0,0),300:(self.scale*8,self.scale*8,self.scale*8)},True)
        
        for i in range(20):
            self.shields.append(bs.newNode('shield',attrs={'color':(random.random(),random.random(),random.random()),'radius':self.scale*2,'position':self.position}))
        def sound():   
            bs.playSound(bs.getSound('blackHole'))
        sound()
        if infinity:
            self.sound2 = bs.Timer(25000,bs.Call(sound),repeat = infinity)
        

    def addMass(self):
        self.scale += 0.15
        self.node.scale = (self.scale,self.scale,self.scale)
        for i in range(2):
            self.shields.append(bs.newNode('shield',attrs={'color':(random.random(),random.random(),random.random()),'radius':self.scale+0.15,'position':self.position}))
            
    def explode(self):
        bs.emitBGDynamics(position=self.position,count=500,scale=1,spread=1.5,chunkType='spark')
        for i in self.shields: bsUtils.animate(i,"radius",{0:0,200:i.radius*5})
        bs.Blast(position = self.position,blastRadius = 10).autoRetain()
        for i in self.shields: i.delete()
        self.node.delete()
        self.suckRadius.delete()
        self.node.handleMessage(bs.DieMessage())
        self.suckRadius.handleMessage(bs.DieMessage())
        

    def touchedSpaz(self):
        node = bs.getCollisionInfo('opposingNode')
        bs.Blast(position = node.position,blastType = 'agentHead').autoRetain()
        if node.exists():
            if self.owner.exists():
                node.handleMessage(bs.HitMessage(magnitude=1000.0,sourcePlayer = self.owner.getDelegate().getPlayer()))
                try:
                    node.handleMessage(bs.DieMessage())
                except:
                    pass
                bs.shakeCamera(2)
            else:
                node.handleMessage(bs.DieMessage())
        self.addMass()
        
    def touchedObj(self):
        node = bs.getCollisionInfo('opposingNode')
        bs.Blast(position = node.position,blastType = 'agentHead').autoRetain()
        if node.exists():
            node.handleMessage(bs.DieMessage())
            
            
        
    def touchedObjSuck(self):
        node = bs.getCollisionInfo('opposingNode')
        if node.getNodeType() in ['prop','bomb']:
            self.suckObjects.append(node)
        
        for i in self.suckObjects:
            if i.exists():
                if i.sticky:
                    i.sticky = False
                    i.extraAcceleration = (0,10,0)
                else:
                    i.extraAcceleration = ((self.position[0] - i.position[0])*8,(self.position[1] - i.position[1])*25,(self.position[2] - i.position[2])*8)
        
    def handleMessage(self,m):
        if isinstance(m,bs.DieMessage):
            if self.node.exists():
                self.node.delete()
            if self.suckRadius.exists():
                self.suckRadius.delete()
            self._updTimer = None
            self._suckTimer = None
            self.sound2 = None
            self.suckObjects = []
        elif isinstance(m,bs.OutOfBoundsMessage):
            self.node.handleMessage(bs.DieMessage())
        elif isinstance(m,BlackHoleMessage):
            print 'ww'
            node = bs.getCollisionInfo('opposingNode')
            bs.Blast(position = self.position,blastType = 'agentHead').autoRetain()
            if not node.invincible:
                node.shattered = 2
        
class Artillery(object):
    def __init__(self,position = (0,1,0),target = None,owner = None,bombType = 'impact',sourcePlayer = None):
    
        self.position = position
        self.owner = owner
        self.target = target
        self.bombType = bombType
        self.sourcePlayer = sourcePlayer
        self.radius = 60
        
        
        self.maxHeight = bs.getActivity().getMap().getDefBoundBox('levelBounds')

        
        self.aimZone = bs.Material()
        self.aimZone.addActions(conditions=(('theyHaveMaterial', bs.getSharedObject('playerMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedSpaz)))
        
        
        self.node = bs.newNode('region',
                       attrs={'position':self.position,
                              'scale':(0.5,0.5,0.5),
                              'type':'sphere',
                              'materials':[self.aimZone]})
        
        bsUtils.animateArray(self.node,"scale",3,{0:(0.5,0.5,0.5),100:(self.radius,self.radius,self.radius)})
        bs.gameTimer(101,self.node.delete)
        bs.gameTimer(102,self.strike)
        
    def touchedSpaz(self):
        node = bs.getCollisionInfo('opposingNode')
        if self.owner is not None:
            if not node == self.owner:
                self.target = node
                self.node.materials = [bs.Material()]
                bs.gameTimer(300,self.node.delete)

        
    def strike(self):
        if self.target is not None:
            def launchBomb():
                if self.target is not None and self.target.exists():
                    self.pos = self.target.position
                    b = bs.Bomb(position = self.position,velocity = (0,5,0),bombType = self.bombType,napalm = True).autoRetain()
                    b.node.extraAcceleration = (0,700,0)
                    b.node.velocity = (b.node.velocity[0]+(self.pos[0]-b.node.position[0]),10, b.node.velocity[2]+(self.pos[2]-b.node.position[2]))
                    bs.playSound(bs.getSound('Aim'))
            bs.gameTimer(100,bs.Call(launchBomb))
            bs.gameTimer(200,bs.Call(launchBomb))
            bs.gameTimer(300,bs.Call(launchBomb))
            bs.gameTimer(400,bs.Call(launchBomb))
            bs.gameTimer(500,bs.Call(launchBomb))
            bs.gameTimer(700,bs.Call(launchBomb))
            bs.gameTimer(900,bs.Call(self.drop))
        
    def drop(self):
        print 'droped'
        def launchBombDrop():
            bs.playSound(bs.getSound('Aim'))
            b = bs.Bomb(position = (self.pos[0]+(-2+random.random()*4),self.maxHeight[4],self.pos[2]+(-2+random.random()*4)),velocity = (0,-100,0),bombType = self.bombType,sourcePlayer = self.sourcePlayer).autoRetain()
            b.node.extraAcceleration = (0,-100,0)
        bs.gameTimer(100,bs.Call(launchBombDrop))
        bs.gameTimer(300,bs.Call(launchBombDrop))
        bs.gameTimer(500,bs.Call(launchBombDrop))
        bs.gameTimer(700,bs.Call(launchBombDrop))
        bs.gameTimer(900,bs.Call(launchBombDrop))
        bs.gameTimer(1000,bs.Call(launchBombDrop))
        
class Flash(object):
    def __init__(self,position = (0,1,0),radius=2.5,time = 8000):
        self.position = position
        
        self.poisonMaterial = bs.Material()
        self.poisonMaterial.addActions(conditions=(('theyHaveMaterial', bs.getSharedObject('playerMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedSpaz)))
        self.radius = radius

        self.node = bs.newNode('region',
                       attrs={'position':(self.position[0],self.position[1],self.position[2]),
                              'scale':(0.1,0.1,0.1),
                              'type':'sphere',
                              'materials':[self.poisonMaterial]})
                              
        self.visualRadius = bs.newNode('shield',attrs={'position':self.position,'color':(1,0,1),'radius':0.1})
        
        bsUtils.animate(self.visualRadius,"radius",{0:0,500:self.radius*2})
        bsUtils.animateArray(self.node,"scale",3,{0:(0,0,0),500:(self.radius,self.radius,self.radius)},True)
        
        bs.gameTimer(7700,bs.WeakCall(self.anim))
        bs.gameTimer(time,self.node.delete)
        bs.gameTimer(time,self.visualRadius.delete)
        
    def anim(self):
        bsUtils.animate(self.visualRadius,"radius",{0:self.radius*2,200:0})
        bsUtils.animateArray(self.node,"scale",3,{0:(self.radius,self.radius,self.radius),200:(0,0,0)})
        
    def touchedSpaz(self):
        node = bs.getCollisionInfo('opposingNode')
        node.handleMessage("knockout",5000)
        
    def delete(self):
        self.node.delete()
        self.visualRadius.delete()

class Poison(bs.Actor):
    def __init__(self,position = (0,1,0),radius=2.2,owner = None):
        ######################################
        # Dont ask me, how in works!         #
        # I am too lazy to use a factory!(2) #
        ######################################
        self.position = position
        bs.Actor.__init__(self)
        self.poisonMaterial = bs.Material()
        self.radius = radius
        self.poisonMaterial.addActions(conditions=(('theyHaveMaterial', bs.getSharedObject('playerMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedSpaz)))
        self.node = bs.newNode('region',
                       owner=owner,
                       attrs={'position':(self.position[0],self.position[1],self.position[2]),
                              'scale':(0.1,0.1,0.1),
                              'type':'sphere',
                              'materials':[self.poisonMaterial]})
        self.visualRadius = bs.newNode('shield',attrs={'position':self.position,'color':(0.3,0.3,0),'radius':0.1})
        bsUtils.animate(self.visualRadius,"radius",{0:0,200:self.radius*2,400:0})
        bsUtils.animateArray(self.node,"scale",3,{0:(0,0,0),200:(self.radius,self.radius,self.radius),400:(0,0,0)})
        bs.gameTimer(250,self.node.delete)
        bs.gameTimer(250,self.visualRadius.delete)
        bs.emitBGDynamics(position=self.position,count=100,emitType='tendrils',tendrilType='smoke')
        
    def touchedSpaz(self):
        node = bs.getCollisionInfo('opposingNode')
        node.getDelegate().curse()
        
    def delete(self):
        self.node.delete()
        self.visualRadius.delete()
    
class Napalm(object):
    def __init__(self,position = (0,-0.1,0), radius = 1.2,time = 5000):
        self.radius = radius
        self.position = position if not position == (0,-0.1,0) else (random.uniform(-4,4),0.1,random.uniform(-4,4))
        self.stop = False
        self.sound = bs.getSound('blank')
        
        self.spawnSmoke(pos = self.position)
        self.spawnFire(pos = self.position)
        self.doSound(pos = self.position)
        
        self.firem = bs.Material()
        self.firem.addActions(conditions=(('theyHaveMaterial', bs.getSharedObject('playerMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedSpaz)))
        self.firem.addActions(conditions=(('theyHaveMaterial', bs.getSharedObject('objectMaterial')),'and',('theyDontHaveMaterial', bs.getSharedObject('playerMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedObj)))

        self.node = bs.newNode('region',
                       attrs={'position':(self.position[0],self.position[1],self.position[2]),
                              'scale':(0.1,0.1,0.1),
                              'type':'sphere',
                              'materials':[self.firem]})
        
        bsUtils.animateArray(self.node,"scale",3,{0:(0,0,0),100:(self.radius/2,self.radius/2,self.radius/2)},True)
        
        self.fireLight = bs.newNode('light',
                            attrs={'position':self.position,
                                   'color':(1,0.4,0),
                                   'volumeIntensityScale':0.1,
                                   'intensity':0.8,
                                   'radius':radius/5})
                               
        self.c2 = bs.animate(self.fireLight,"intensity",{0:random.uniform(0.8,1.5),100:random.uniform(0.8,1.5),200:random.uniform(0.8,1.5),300:random.uniform(0.8,1.5),400:random.uniform(0.8,1.5),500:random.uniform(0.8,1.5),600:random.uniform(0.8,1.5),700:random.uniform(0.8,1.5),800:random.uniform(0.8,1.5),900:random.uniform(0.8,1.5),1000:random.uniform(0.8,1.5),1100:random.uniform(0.8,1.5),1200:random.uniform(0.8,1.5),1300:random.uniform(0.8,1.5)},True)
        self.c3 = bs.animateArray(self.fireLight,"color",3,{0:(1,0.4,0),100:(1,0.3,0),200:(1,0.6,0),300:(1,0.5,0),400:(1,0.2,0),500:(1,0.4,0),600:(1,0.3,0)},True)
               
        self.scorch = bs.newNode('scorch',
                                  attrs={'position':self.position,'size':radius*0.5,'big':True,'color':(0.1,0.0,0.0)})
        self.c4 = bsUtils.animate(self.scorch,"presence",{0:0.1, int(time/3):radius})
        
        
        
        def stopIt():
            self.stop = True
            self.c2.delete()
            self.c4.delete()
            if self.node is not None and self.node.exists(): self.node.delete()
            self.fireLight.delete()
            bsUtils.animate(self.scorch,"presence",{0:self.scorch.presence, 8000:0})
            bs.gameTimer(8001,self.scorch.delete)
            
        bs.gameTimer(time,stopIt)

    def touchedSpaz(self):
        node = bs.getCollisionInfo('opposingNode')
        if node.getNodeType() == 'spaz':
            if not node.getDelegate().fired:
            	node.getDelegate().fire()
            
    def touchedObj(self):
        node = bs.getCollisionInfo('opposingNode')
        if node.exists():
            try:
                node.getDelegate().explode()
            except:
                pass
                               
    def spawnSmoke(self,pos):
        pos = (pos[0]+random.uniform(-self.radius/2,self.radius/2),pos[1]+0.2,pos[2]+random.uniform(-self.radius/2,self.radius/2))
        bs.emitBGDynamics(position=pos,velocity=(0,0,0),count=1,emitType='tendrils',tendrilType='smoke')
        if not self.stop:
            bs.gameTimer(1800,bs.Call(self.spawnSmoke,pos = self.position))
            
    def doSound(self,pos):
        bs.playSound(self.sound,position = pos)
        if not self.stop:
            bs.gameTimer(2900,bs.Call(self.doSound,pos = self.position))
        
    def spawnFire(self,pos):
        pos = (pos[0]+random.uniform(-self.radius/2,self.radius/2),pos[1],pos[2]+random.uniform(-self.radius/2,self.radius/2))
        
        #if math.sqrt((self.position[0]+pos[0])*(self.position[0]+pos[0]) + (self.position[2]+pos[2])*(self.position[2]+pos[2])) <= self.radius:
        bs.emitBGDynamics(position=(pos),velocity=(0,7,0),count=int(5+random.random()*5),scale=random.random()*2,spread=random.random()*0.2,chunkType='sweat')
        if not self.stop:
            bs.gameTimer(5,bs.Call(self.spawnFire,self.position))
        # else:
            # if not self.stop:
                # bs.gameTimer(1,bs.Call(self.spawnFire,self.position))
        
class AutoAim(object):

    def __init__(self, whoControl, owner):
        self.whoControl = whoControl
        self.owner = owner
        self.target = None
        self.node = None
        self.aimZoneSpaz = bs.Material()
        self.aimZoneSpaz.addActions(
            conditions=(('theyHaveMaterial',
                         bs.getSharedObject('playerMaterial'))),
            actions=(('modifyPartCollision', 'collide', True),
                     ('modifyPartCollision', 'physical', False),
                     ('call', 'atConnect', self.touchedSpaz)))

        self.whoControl.extraAcceleration = (0, 20, 0)

        if self.whoControl.exists():
            self.node = bs.newNode('region', attrs={
                'position': (self.whoControl.position[0],
                             self.whoControl.position[1],
                             self.whoControl.position[2]),
                'scale': (0.1, 0.1, 0.1),
                'type': 'sphere',
                'materials': [self.aimZoneSpaz]})
        else:
            self.node = bs.newNode('region', attrs={
                'position': (0, 0, 0),
                'scale': (0.1, 0.1, 0.1),
                'type': 'sphere',
                'materials': [self.aimZoneSpaz]})

        bs.animateArray(self.node, 'scale', 3,
                        {0: (0.1, 0.1, 0.1), 1200: (60, 60, 60)})

    def go(self):
        if self.target is not None \
                and self.whoControl is not None \
                and self.whoControl.exists():
            self.whoControl.velocity = \
                (self.whoControl.velocity[0]+(
                    self.target.position[0]-self.whoControl.position[0]),
                 self.whoControl.velocity[1]+(
                    self.target.position[1]-self.whoControl.position[1]),
                 self.whoControl.velocity[2]+(
                    self.target.position[2]-self.whoControl.position[2]))

            bs.gameTimer(1, self.go)

    def touchedSpaz(self):
        node = bs.getCollisionInfo('opposingNode')
        try:
            if node is not None \
                    and node.exists() \
                    and node != self.owner \
                    and node.getDelegate().isAlive() \
                    and node.getDelegate().getPlayer().getTeam() \
                    != self.owner.getDelegate().getPlayer().getTeam():
                self.target = node
                self.node.delete()
                self.whoControl.extraAcceleration = (0, 20, 0)
                self.go()
        except:
            if node is not None \
                    and node.exists() \
                    and node != self.owner \
                    and node.getDelegate().isAlive():
                self.target = node
                self.node.delete()
                self.whoControl.extraAcceleration = (0, 20, 0)
                self.go()

    def off(self):
        def sa():
            self.target = None

        bs.gameTimer(100, sa)
        
class BlackHole(object):
    def __init__(self,position = (0,1,0),autoExpand = True,scale = 1,doNotRandomize = False,infinity = False,owner = None):
        self.shields = []
        
        self.position = (position[0]-2+random.random()*4,position[1]+random.random()*2,position[2]-2+random.random()*4) if not doNotRandomize else position
        self.scale = scale
        self.suckObjects = []
        
        self.owner = owner
        
        self.blackHoleMaterial = bs.Material()
        self.suckMaterial = bs.Material()
        self.blackHoleMaterial.addActions(conditions=(('theyDontHaveMaterial', bs.getSharedObject('objectMaterial')),'and',('theyHaveMaterial', bs.getSharedObject('playerMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedSpaz)))
                                                      
        self.blackHoleMaterial.addActions(conditions=(('theyDontHaveMaterial', bs.getSharedObject('playerMaterial')),'and',('theyHaveMaterial', bs.getSharedObject('objectMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedObj)))
                                                  
        self.suckMaterial.addActions(conditions=(('theyHaveMaterial', bs.getSharedObject('objectMaterial'))),actions=(("modifyPartCollision","collide",True),
                                                      ("modifyPartCollision","physical",False),
                                                      ("call","atConnect", self.touchedObjSuck)))
                                                  
                                                  
        self.node = bs.newNode('region',
                       attrs={'position':(self.position[0],self.position[1],self.position[2]),
                              'scale':(scale,scale,scale),
                              'type':'sphere',
                              'materials':[self.blackHoleMaterial]})
                              
        self.suckRadius = bs.newNode('region',
                       attrs={'position':(self.position[0],self.position[1],self.position[2]),
                              'scale':(scale,scale,scale),
                              'type':'sphere',
                              'materials':[self.suckMaterial]})
                              
        def dist():
            bs.emitBGDynamics(position=self.position,emitType='distortion',spread=6,count = 100)
            if self.node.exists():
                bs.gameTimer(1000,dist)
                
        dist()
        
        if not infinity:
            self._dieTimer = bs.Timer(25000,bs.WeakCall(self.explode))
        bsUtils.animateArray(self.node,"scale",3,{0:(0,0,0),300:(self.scale,self.scale,self.scale)},True)
        bsUtils.animateArray(self.suckRadius,"scale",3,{0:(0,0,0),300:(self.scale*8,self.scale*8,self.scale*8)},True)
        
        for i in range(20):
            self.shields.append(bs.newNode('shield',attrs={'color':(random.random(),random.random(),random.random()),'radius':self.scale*2,'position':self.position}))
        def sound():   
            bs.playSound(bs.getSound('explosion05'))
        sound()
        if infinity:
            self.sound2 = bs.Timer(25000,bs.Call(sound),repeat = infinity)
        

    def addMass(self):
        self.scale += 0.15
        self.node.scale = (self.scale,self.scale,self.scale)
        for i in range(2):
            self.shields.append(bs.newNode('shield',attrs={'color':(random.random(),random.random(),random.random()),'radius':self.scale+0.15,'position':self.position}))
            
    def explode(self):
        bs.emitBGDynamics(position=self.position,count=500,scale=1,spread=1.5,chunkType='spark')
        for i in self.shields: bsUtils.animate(i,"radius",{0:0,200:i.radius*5})
        bs.Blast(position = self.position,blastRadius = 10).autoRetain()
        for i in self.shields: i.delete()
        self.node.delete()
        self.suckRadius.delete()
        self.node.handleMessage(bs.DieMessage())
        self.suckRadius.handleMessage(bs.DieMessage())
        

    def touchedSpaz(self):
        node = bs.getCollisionInfo('opposingNode')
        bs.Blast(position = node.position,blastType = 'agentHead').autoRetain()
        if node.exists():
            if self.owner.exists():
                node.handleMessage(bs.HitMessage(magnitude=1000.0,sourcePlayer = self.owner.getDelegate().getPlayer()))
                try:
                    node.handleMessage(bs.DieMessage())
                except:
                    pass
                bs.shakeCamera(2)
            else:
                node.handleMessage(bs.DieMessage())
        self.addMass()
        
    def touchedObj(self):
        node = bs.getCollisionInfo('opposingNode')
        bs.Blast(position = node.position,blastType = 'normal').autoRetain()
        if node.exists():
            node.handleMessage(bs.DieMessage())
            
            
        
    def touchedObjSuck(self):
        node = bs.getCollisionInfo('opposingNode')
        if node.getNodeType() in ['prop','bomb']:
            self.suckObjects.append(node)
        
        for i in self.suckObjects:
            if i.exists():
                if i.sticky:
                    i.sticky = False
                    i.extraAcceleration = (0,10,0)
                else:
                    i.extraAcceleration = ((self.position[0] - i.position[0])*8,(self.position[1] - i.position[1])*25,(self.position[2] - i.position[2])*8)
        
    def handleMessage(self,msg):
        if isinstance(msg,bs.DieMessage):
            if self.node.exists():
                self.node.delete()
            if self.suckRadius.exists():
                self.suckRadius.delete()
            self._updTimer = None
            self._suckTimer = None
            self.sound2 = None
            self.suckObjects = []
        elif isinstance(msg,bs.OutOfBoundsMessage):
            self.node.handleMessage(bs.DieMessage())
        elif isinstance(msg,BlackHoleMessage):
            print 'ww'
            node = bs.getCollisionInfo('opposingNode')
            bs.Blast(position = self.position,blastType = 'normal').autoRetain()
            if not node.invincible:
                node.shattered = 2
