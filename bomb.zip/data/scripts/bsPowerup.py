import bs
import random
import bsUtils
import bsSpaz
from bsSpaz import Spaz
import BuddyBunny
import SnoBallz
import settings
import material
import Portal
import bsInternal

defaultPowerupInterval = 8000

class PowerupMessage(object):
    """
    category: Message Classes

    Tell something to get a powerup.
    This message is normally recieved by touching
    a bs.Powerup box.
    
    Attributes:
    
       powerupType
          The type of powerup to be granted (a string).
          See bs.Powerup.powerupType for available type values.

       sourceNode
          The node the powerup game from, or an empty bs.Node ref otherwise.
          If a powerup is accepted, a bs.PowerupAcceptMessage should be sent
          back to the sourceNode to inform it of the fact. This will generally
          cause the powerup box to make a sound and disappear or whatnot.
    """
    def __init__(self,powerupType,sourceNode=bs.Node(None)):
        """
        Instantiate with given values.
        See bs.Powerup.powerupType for available type values.
        """
        self.powerupType = powerupType
        self.sourceNode = sourceNode

class PowerupAcceptMessage(object):
    """
    category: Message Classes

    Inform a bs.Powerup that it was accepted.
    This is generally sent in response to a bs.PowerupMessage
    to inform the box (or whoever granted it) that it can go away.
    """
    pass

class _TouchedMessage(object):
    pass

class PowerupFactory(object):
    """
    i delete those fuck script, i fucked it and deleted it
    """

    def __init__(self):
        """
        Instantiate a PowerupFactory.
        You shouldn't need to do this; call bs.Powerup.getFactory()
        to get a shared instance.
        """

        self._lastPowerupType = None

        self.model = bs.getModel("powerup")
        self.modelSimple = bs.getModel("powerupSimple")

        self.texIceBombs = bs.getTexture("powerupIceBombs")
        self.texStickyBombs = bs.getTexture("powerupStickyBombs")
        self.texLandMine = bs.getTexture("powerupLandMines")
        self.texImpactBombs = bs.getTexture("powerupImpactBombs")
        self.texImpactIce = bs.getTexture("egg2")
        self.texBackflip = bs.getTexture("buttonBomb")
        self.texTimeBombs = bs.getTexture("achievementMine")

        self.texBomb = bs.getTexture("powerupBomb")
        self.texPunch = bs.getTexture("powerupPunch")
        self.texFreezeBombs = bs.getTexture("ouyaUButton")
        self.texShield = bs.getTexture("powerupShield")
        self.texHealth = bs.getTexture("powerupHealth")
        self.texLandMines = bs.getTexture("landMine")
        self.texCurse = bs.getTexture("powerupCurse")
        self.texFireBombs = bs.getTexture("achievementOnslaught")
        self.texSpeed = bs.getTexture("achievementGotTheMoves")
        self.texspunch = bs.getTexture("achievementSuperPunch")
        self.texDynamite = bs.getTexture("landMineLit")
        self.texPlasmaBombs = bs.getTexture("buttonBomb")
        self.texJump = bs.getTexture("upButton")
        self.texCurseBombs = bs.getTexture("bonesColor")
        self.texKnockerBombs = bs.getTexture("nub")
        self.texHealthAdder = bs.getTexture("achievementStayinAlive")
        self.texIronSkin = bs.getTexture("levelIcon")
        self.texHealBombs = bs.getTexture("achievementStayinAlive")
        self.texTrapBombs = bs.getTexture('achievementWall')
        self.texShockWave = bs.getTexture('egg1')
        self.texFlashBombs = bs.getTexture('levelIcon')
        self.texFlyBombs = bs.getTexture('achievementOffYouGo')
        self.texFloatBombs = bs.getTexture('buttonPickUp')
        self.texBombSpawner = bs.getTexture('downButton')
        self.texBot = bs.getTexture('achievementSharingIsCaring')
        self.texInvisible = bs.getTexture('crossOut')
        self.texBoxBomb = bs.getTexture('menuButton')
        self.texstrongIce = bs.getTexture('menuButton')
        self.texTNT = bs.getTexture('achievementFootballShutout')
        self.texGrom = bs.getTexture('ouyaOButton')
        self.texSpikes = bs.getTexture('smoke')
        self.texFlash = bs.getTexture('ouyaAButton')
        self.texElonMine = bs.getTexture('achievementCrossHair')
        self.texForce = bs.getTexture('egg3')
        self.texFlyer = bs.getTexture('buttonPickUp')
        self.texHighJump = bs.getTexture('buttonJump')
        self.texGod = bs.getTexture("shield")
        self.texArtillery = bs.getTexture("coin")
        ####### model ########
        self.bombModel = bs.getModel("bomb")
        self.stickyBomb = bs.getModel("bombSticky")
        self.impactBomb = bs.getModel("impactBomb")
        self.landmine = bs.getModel("landMine")
        self.punch = bs.getModel("boxingGlove")
        self.curse = bs.getModel("bonesHead")
        

        self.healthPowerupSound = bs.getSound("healthPowerup")
        self.powerupSound = bs.getSound("powerup01")
        self.powerdownSound = bs.getSound("powerdown01")
        self.dropSound = bs.getSound("boxDrop")

        # material for powerups
        self.powerupMaterial = bs.Material()

        # material for anyone wanting to accept powerups
        self.powerupAcceptMaterial = bs.Material()

        # pass a powerup-touched message to applicable stuff
        self.powerupMaterial.addActions(
            conditions=(("theyHaveMaterial",self.powerupAcceptMaterial)),
            actions=(("modifyPartCollision","collide",True),
                     ("modifyPartCollision","physical",False),
                     ("message","ourNode","atConnect",_TouchedMessage())))

        # we dont wanna be picked up
        self.powerupMaterial.addActions(
            conditions=("theyHaveMaterial",
                        bs.getSharedObject('pickupMaterial')),
            actions=( ("modifyPartCollision","collide",False)))

        self.powerupMaterial.addActions(
            conditions=("theyHaveMaterial",
                        bs.getSharedObject('footingMaterial')),
            actions=(("impactSound",self.dropSound,0.5,0.1)))

        self._powerupDist = []
        for p,freq in getDefaultPowerupDistribution():
            for i in range(int(freq)):
                self._powerupDist.append(p)

    def getRandomPowerupType(self,forceType=None,excludeTypes=[]):
        """
        Returns a random powerup type (string).
        See bs.Powerup.powerupType for available type values.

        There are certain non-random aspects to this; a 'curse' powerup,
        for instance, is always followed by a 'health' powerup (to keep things
        interesting). Passing 'forceType' forces a given returned type while
        still properly interacting with the non-random aspects of the system
        (ie: forcing a 'curse' powerup will result
        in the next powerup being health).
        """
        if forceType:
            t = forceType
        else:
            # if the last one was a curse, make this one a health to
            # provide some hope
            if self._lastPowerupType == 'curse':
                t = 'health'
            else:
                while True:
                    t = self._powerupDist[
                        random.randint(0, len(self._powerupDist)-1)]
                    if t not in excludeTypes:
                        break
        self._lastPowerupType = t
        return t


def getDefaultPowerupDistribution():
    return (('tripleBombs',3),
            ('iceBombs',3),
            ('punch',0),
            ('impactBombs',3),
            ('landMines',2),
            ('stickyBombs',3),
            ('shield',0),
            ('health',1),
            ('bot',2),
            ('freezeBombs',1),
            ('jump',0),
            ('locatorBombs',0),
            ('speed',1),
            ('shot',0),
            ('bombSpawner',1),
            ('curseBombs',1),
            ('dynamite',2),
            ('flyBombs',0),
            ('knockerBombs',1),
            ('healthAdder',0),
            ('impactIce',1),
            ('plasmaBombs',1),
            ('resistance',0),
            ('floatBombs',0),
            ('healBombs',2),
            ('backflip',0),
            ('forceBombs',2),
            ('luckyBox',3),
            ('invisible',2),
            ('strongice',2),
            ('tnt',0),
            ('highJump',1),
            ('elonMine',0),
            ('spikes',2),
            ('Flyer',3),
            ('shockWave',1),
            ('flashBombs',1),
            ('timeBombs',2),
            ('trapBombs',2),
            ('spunch',0), # i had learned to sobydamn to create this powerup.
            ('fireBombs',2), # adapted from JRMP and Bombdash firebombs, i mix it.
            ('curse',1),
            ('grom',1),
            ('god',0),
            ('artillery',2))

class Powerup(bs.Actor):
    """
    category: Game Flow Classes

    A powerup box.
    This will deliver a bs.PowerupMessage to anything that touches it
    which has the bs.PowerupFactory.powerupAcceptMaterial applied.

    Attributes:

       powerupType
          The string powerup type.  This can be 'tripleBombs', 'punch',
          'iceBombs', 'impactBombs', 'landMines', 'stickyBombs', 'shield',
          'health', or 'curse'.

       node
          The 'prop' bs.Node representing this box.
    """

    def __init__(self,position=(0,1,0),powerupType='tripleBombs',expire=True):
        """
        Create a powerup-box of the requested type at the requested position.

        see bs.Powerup.powerupType for valid type strings.
        """
        
        bs.Actor.__init__(self)

        factory = self.getFactory()
        self.powerupType = powerupType;
        self._powersGiven = False
        
        mod = factory.model
        mScl = 1.0
        name = " "
        if powerupType == 'tripleBombs':
            tex = factory.texBomb
            name = "Triple Bombs"
        elif powerupType == 'punch':
            tex = factory.texPunch
            name = "Boxing Gloves"
        elif powerupType == 'highJump':
            tex = factory.texHighJump
            name = "High Jump"
        elif powerupType == 'iceBombs':
            tex = factory.texIceBombs
            name = "Ice Bombs"
        elif powerupType == 'impactBombs':
            tex = factory.texImpactBombs
            name = "Impact Bombs"
        elif powerupType == 'landMines':
            tex = factory.texLandMines
            mod = factory.landmine
            name = "Land Mines"
        elif powerupType == 'stickyBombs': 
            tex = factory.texStickyBombs
            name = "Sticky Bombs"
        elif powerupType == 'freezeBombs':
            tex = factory.texFreezeBombs
            name = "Freeze Bombs"
        elif powerupType == 'knockerBombs':
            tex = factory.texKnockerBombs
            name = "Knocker Bombs"
        elif powerupType == 'curseBombs': 
            tex = factory.texCurseBombs
            mod = factory.curse
            name = "Curse Bomb"
        elif powerupType == 'timeBombs':
            tex = factory.texTimeBombs
            name = "Time Bombs"
        elif powerupType == 'elonMine':
            tex = factory.texElonMine
            name = "Tracker"
        elif powerupType == 'shot':
            tex = factory.texFlash
            name = "Plasma Bombs"
        elif powerupType == 'luckyBox': 
            tex = bs.getTexture('achievementEmpty')
            name = "Lucky Box"
        elif powerupType == 'forceBombs':
            tex = factory.texForce
            name = "Force Bomb"
        elif powerupType == 'grom': 
            tex = factory.texGrom
            name = "Portal"
        elif powerupType == 'tnt':
            tex = factory.texTNT
            name = "3 TNT Packs"
        elif powerupType == 'shield':
            tex = factory.texShield
            name = "Shields"
        elif powerupType == 'locatorBombs':
            tex = factory.texBoxBomb
            name = "Locator Bombs"
        elif powerupType == 'invisible':
            tex = factory.texInvisible
            name = "Invisibility"
        elif powerupType == 'bot':
            tex = factory.texBot
            name = "Buddy Bot"
        elif powerupType == 'strongice':
            tex = factory.texstrongIce
            name = "Strong Ice"
        elif powerupType == 'bombSpawner':
            tex = factory.texBombSpawner
            name = "Meteor Spawner"
        elif powerupType == 'floatBombs':
            tex = factory.texFloatBombs
            name = "Floating Bombs"
        elif powerupType == 'flyBombs':
            tex = factory.texFlyBombs
            name = "Fly Effect Bombs"
        elif powerupType == 'Flyer':
            tex = factory.texFlyer
            name = "Flyer Ball"
        elif powerupType == 'impactIce':
            tex = factory.texImpactIce
            name = "ImpactIce Bombs"
        elif powerupType == 'flashBombs':
            tex = factory.texFlashBombs
            name = "Sleep Bomb"
        elif powerupType == 'trapBombs':
            tex = factory.texTrapBombs
            name = "Trap Bombs"
        elif powerupType == 'resistance':
            tex = factory.texIronSkin
            name = "Super Star"
        elif powerupType == 'speed':
            tex = factory.texSpeed
            name = "Speed Boots"
        elif powerupType == 'health':
            tex = factory.texHealth
            name = "Bandage"
        elif powerupType == 'curse':
            tex = factory.texCurse
            name = "Curse"
        elif powerupType == 'spikes':
            tex = factory.texSpikes
            name = "Laser"
        elif powerupType == 'spunch':
            tex = factory.texspunch
            name = "Speed Punch"
        elif powerupType == 'jump':
            tex = factory.texJump
            name = "High Jump"
        elif powerupType == 'shockWave':
            tex = factory.texShockWave
            name = "ShockWave"
        elif powerupType == 'healthAdder':
            tex = factory.texHealthAdder
            name = "Health Adder"
        elif powerupType == 'plasmaBombs':
            tex = factory.texPlasmaBombs
            name = "Plasma Bombs"
        elif powerupType == 'dynamite':
            tex = factory.texDynamite
            name = "Dynamites"
        elif powerupType == 'healBombs':
            tex = factory.texHealBombs
            name = "Heal Bomb"
        elif powerupType == 'backflip':
            tex = factory.texBackflip
            name = "3d Fly Blast"
        elif powerupType == 'fireBombs':
            tex = factory.texFireBombs
            name = "Fire Bombs"
        elif powerupType == 'god': 
            tex = factory.texGod
            name = "Lego"
        elif powerupType == 'artillery':
            tex = factory.texArtillery
            name = "Impact Shower"
        else: raise Exception("invalid powerupType: "+str(powerupType))

        if len(position) != 3: raise Exception("expected 3 floats for position")
        self.node = bs.newNode('prop',
                               delegate=self,
                               attrs={'body': 'box',
                                      'position': position,
                                      'model': mod,
                                      'lightModel': factory.modelSimple,
                                      'shadowSize': 0.5,
                                      'colorTexture': tex,
                                      'reflection': 'powerup',
                                      'reflectionScale': [1.0],
                                      'materials': (factory.powerupMaterial, bs.getSharedObject('objectMaterial'))})
        bs.emitBGDynamics(position=self.node.position,velocity=(0,0,0),spread=2.2,scale=1.8,count=70,chunkType='spark')                                      
        if settings.animateOnPwps:
        	prefixAnim = {0: (3,0,0), 350: (3,3,0), 350 * 2: (3,3,3), 350 * 3: (0,3,3), 350 * 4: (3,0,3),
                      350 * 5: (3,3,0), 350 * 6: (3,0,0)}
        color = (1,1,1)              
        color = (random.random(), random.random(), random.random())
        
        if settings.nameOnPwps:
            m = bs.newNode('math', owner=self.node, attrs={'input1': (0, 0.7, 0), 'operation': 'add'})
            self.node.connectAttr('position', m, 'input2')
            self.nodeText = bs.newNode('text',
                                       owner=self.node,
                                       attrs={'text': u'\ue043[' + name + u']\ue043',
                                              'inWorld': True,
                                              'shadow': 1.0,
                                              'flatness': 1.0,
                                              'color': color,
                                              'scale': 0.5,
                                              'hAlign': 'center'})
            m.connectAttr('output', self.nodeText, 'position')
            bs.animate(self.nodeText, 'scale', {0: 0, 140: 0.016, 200: 0.01})
        if settings.animateOnPwps:
            bs.animateArray(self.nodeText,'color',3,{0:(0,0,2),500:(0,2,0),1000:(2,0,0),1500:(2,2,0),2000:(2,0,2),2500:(0,1,6),3000:(1,2,0)},True)

        if settings.discoLightOnPwps:
            self.nodeLight = bs.newNode('light',
                                        attrs={'position': self.node.position,
                                               'color': color,
                                               'radius': 0.12,
                                               'volumeIntensityScale': 0.5})
            self.node.connectAttr('position', self.nodeLight, 'position')             
            bsUtils.animateArray(self.nodeLight, 'color', 3, prefixAnim, True)
            bs.animate(self.nodeLight, "intensity", {0:1.0, 1000:1.8, 2000:1.0}, loop = True)            
            bs.gameTimer(8000,self.nodeLight.delete)
            
        if settings.shieldOnPwps:
            self.nodeShield = bs.newNode('shield', owner=self.node, attrs={'color': color,
                                                                           'position': (
                                                                               self.node.position[0],
                                                                               self.node.position[1],
                                                                               self.node.position[2] + 0.5),
                                                                           'radius': 1.1})
            self.node.connectAttr('position', self.nodeShield, 'position')
        if settings.animateOnPwps:            
            bsUtils.animateArray(self.nodeShield, 'color', 3, prefixAnim, True)

        # animate in..
        curve = bs.animate(self.node,"modelScale",{0:0,140:1.6,200:mScl})
        bs.gameTimer(200,curve.delete)

        if expire:
            bs.gameTimer(defaultPowerupInterval-2500,
                         bs.WeakCall(self._startFlashing))
            bs.gameTimer(defaultPowerupInterval-1000,
                         bs.WeakCall(self.handleMessage, bs.DieMessage()))

    @classmethod
    def getFactory(cls):
        """
        Returns a shared bs.PowerupFactory object, creating it if necessary.
        """
        activity = bs.getActivity()
        if activity is None: raise Exception("no current activity")
        try: return activity._sharedPowerupFactory
        except Exception:
            f = activity._sharedPowerupFactory = PowerupFactory()
            return f
            
    def _startFlashing(self):
        if self.node.exists(): self.node.flashing = True
        
    def delpor(self):
        Portal.currentnum -= 1
        self.port.delete()
        
    def handleMessage(self, msg):
        self._handleMessageSanityCheck()

        if isinstance(msg, PowerupAcceptMessage):
            factory = self.getFactory()
            if self.powerupType == 'health':
                bs.playSound(factory.healthPowerupSound, 3,
                             position=self.node.position)
            bs.playSound(factory.powerupSound, 3, position=self.node.position)
            self._powersGiven = True
            self.handleMessage(bs.DieMessage())

        elif isinstance(msg, _TouchedMessage):
            if not self._powersGiven:
                node = bs.getCollisionInfo("opposingNode")
                if node is not None and node.exists():
                    # We won't tell the spaz about the bunny.  It'll just happen.
                    if self.powerupType == 'bot':
                    	bsUtils.PopupText(u"\ue046Buddy Bot\ue046", color=(0,3,0), position=self.node.position, scale=1.7).autoRetain()
                        p = node.getDelegate().getPlayer()
                        if not 'bunnies' in p.gameData:
                            p.gameData['bunnies'] = BuddyBunny.BunnyBotSet(p)
                        p.gameData['bunnies'].doBunny()
                        self._powersGiven = True
                        self.handleMessage(bs.DieMessage())
                    elif self.powerupType == 'shot':
                        spaz = node.getDelegate()
                        SnoBallz.snoBall().getFactory().giveBallz(spaz)
                        self._powersGiven = True
                        self.handleMessage(bs.DieMessage())
                        node.boxingGloves = 0
                        bsUtils.PopupText("Plasma Bombs Thrower",color=(0,1,1),position=self.node.position,scale=1).autoRetain()
                    elif self.powerupType == "strongice":
                        p = node.positionForward
                        bs.Bomb((p[0]+0.43,p[1]+4,p[2]-0.25),velocity=(0,-6,0),bombType = 'ice').autoRetain()  
                        bs.Bomb((p[0]+0.43,p[1]+4,p[2]-0.25),velocity=(0,-6,0),bombType = 'ice').autoRetain() 
                        bs.Bomb((p[0]+0.43,p[1]+4,p[2]-0.25),velocity=(0,-6,0),bombType = 'ice').autoRetain()                        
                        bsUtils.PopupText(u"\ue046Strong Ice\ue046", color=(0,1,1), position=self.node.position, scale=1.7).autoRetain()
                        self._powersGiven = True
                        self.handleMessage(bs.DieMessage())
                    elif self.powerupType == 'grom':
                        self.port = Portal.Portal(position1=None, r=0.9,
                                                          color=(random.random(), random.random(), random.random()),
                                                          activity=bs.getActivity())
                        bs.gameTimer(25000,self.port.delete)                                                          
                        self._powersGiven = True
                        self.handleMessage(bs.DieMessage())
                    else:
                        node.handleMessage(PowerupMessage(self.powerupType, sourceNode=self.node))

        elif isinstance(msg, bs.DieMessage):
            if self.node.exists():
                if (msg.immediate):
                    self.node.delete()
                else:
                    curve = bs.animate(self.node, "modelScale", {0:1,100:0})
                    bs.gameTimer(100, self.node.delete)
            if self.nodeLight.exists():
                self.nodeLight.delete()

        elif isinstance(msg ,bs.OutOfBoundsMessage):
            self.handleMessage(bs.DieMessage())

        elif isinstance(msg, bs.HitMessage):
            # dont die on punches or curse, heal, jump, backflip, shockWave, and knock (thats annoying)
            if msg.hitType != 'punch' and msg.hitSubType not in ['knocker','atom','curse','heal','backflip','jump','shockWave']:
                self.handleMessage(bs.DieMessage())
        else:
            bs.Actor.handleMessage(self, msg)
