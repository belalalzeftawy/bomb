from bsSpaz import *
from bsUI import PlayWindow, uiGlobals, PopupWindow, gSmallUI, gMedUI, gTitleColor,\
 uiGlobals, gWindowStates, gToolbars, MainMenuWindow,PlayerProfilesWindow,gDoAndroidNav
import bsUtils,bsUI,bsInternal,bsSpaz, bsMainMenu
from bsBomb import Blast, Bomb
from bsFlag import Flag

newConfig = {"changeColor":False,
             "changeHighlight":False,
             "changeName":False,
             "glowColor":False,
             "glowHighlight":False,
             "glowName":False,
             "tab":'info',
             "shieldColor":False,
             "xplotionColor":True,
             "delScorch":True,
             "colorBots":False,
             "glowBots":False,
             "colorTitle":False,
             "flag":False,
             "glowingBombs":False,
             "glowScale":5,
             "timeDelay":300
            }

if "colorsMod" in bs.getConfig():
    oldConfig = bs.getConfig()["colorsMod"]
    for setting in newConfig:
        if setting not in oldConfig:
            bs.getConfig()["colorsMod"] = newConfig
else:
    bs.getConfig()["colorsMod"] = newConfig
bs.writeConfig()

oldInit = PlayerSpaz.__init__
def newInit(self, *args, **kwargs):
    oldInit(self, *args, **kwargs)
    if bs.getConfig()["colorsMod"]["glowColor"]:
        s = bs.getConfig()["colorsMod"]["glowScale"]
    else: s = 1
    if bs.getConfig()["colorsMod"]["glowHighlight"]:
        s2 = bs.getConfig()["colorsMod"]["glowScale"]
    else: s2 = 1
    if bs.getConfig()["colorsMod"]["glowName"]:
        s3 = bs.getConfig()["colorsMod"]["glowScale"]
    else: s3 = 1
	
    self.node.color = (self.node.color[0]*s,self.node.color[1]*s,self.node.color[2]*s)
    self.node.highlight = (self.node.highlight[0]*s2,self.node.highlight[1]*s2,self.node.highlight[2]*s2)
    self.node.nameColor = (self.node.nameColor[0]*s3,self.node.nameColor[1]*s3,self.node.nameColor[2]*s3)

    def changeColor():
        if self.isAlive():
            if bs.getConfig()["colorsMod"]["changeColor"]:
                self.node.color = (random.random()*s,random.random()*s,random.random()*s)
            if bs.getConfig()["colorsMod"]["changeHighlight"]:
                self.node.highlight = (random.random()*s2,random.random()*s2,random.random()*s2)
            if bs.getConfig()["colorsMod"]["changeName"]:
                self.node.nameColor = (random.random()*s3,random.random()*s3,random.random()*s3)
    bs.gameTimer(bs.getConfig()["colorsMod"]["timeDelay"],bs.Call(changeColor),repeat=True)	
PlayerSpaz.__init__ = newInit

oldBombInit = Bomb.__init__
def newBombInit(self, *args, **kwargs):
    oldBombInit(self, *args, **kwargs)
    self._li = None
    if bs.getConfig()["colorsMod"]["glowingBombs"]:
        self._li = bs.newNode('light',attrs={'position':self.node.position,'radius':0.07,
                                     'color': (1,1,1), 'volumeIntensityScale':1.0})
        bsUtils.animate(self._li,"intensity",{0:0,200:1.5})
        self.node.connectAttr('position',self._li,'position')
        #self.node.colorTexture = bs.getTexture('flagColor')
	
    def changeColor():
        if self._li is None: return
        if bs.getConfig()["colorsMod"]["glowingBombs"]:
            self._li.color = (random.random(),random.random(),random.random())
    self._ct = bs.gameTimer(bs.getConfig()["colorsMod"]["timeDelay"],bs.Call(changeColor),repeat=True)
Bomb.__init__ = newBombInit

oldBombHandleDie = Bomb._handleDie
def newBombHandleDie(self,m):
    self.node.delete()
    if self._li: self._li.delete()
    self._li = None
Bomb._handleDie = newBombHandleDie

oldBotInit = SpazBot.__init__
def newBotInit(self, *args, **kwargs):
    oldBotInit(self, *args, **kwargs)
    if bs.getConfig()["colorsMod"]["glowBots"]:
        s = bs.getConfig()["colorsMod"]["glowScale"]
    else: s = 1
	
    self.node.highlight = (self.node.highlight[0]*s,self.node.highlight[1]*s,self.node.highlight[2]*s)

    def changeColor():
        if self.isAlive():
            if bs.getConfig()["colorsMod"]["colorBots"]:
                self.node.highlight = (random.random()*s,random.random()*s,random.random()*s)
    bs.gameTimer(bs.getConfig()["colorsMod"]["timeDelay"],bs.Call(changeColor),repeat=True)
SpazBot.__init__ = newBotInit

def equipNewShields(self, decay=False):
        if not self.node.exists():
            bs.printError('Can\'t equip shields; no node.')
            return
        factory = self.getFactory()
        if self.shield is None: 
            self.shield = bs.newNode('shield', owner=self.node, attrs={'color':(0.3, 0.2, 2.0),'radius':1.3})
            self.node.connectAttr('positionCenter', self.shield, 'position')
        self.shieldHitPoints = self.shieldHitPointsMax = 650
        self.shieldDecayRate = factory.shieldDecayRate if decay else 0
        self.shield.hurt = 0
        bs.playSound(factory.shieldUpSound, 1.0, position=self.node.position)
        if self.shieldDecayRate > 0:
            self.shieldDecayTimer = bs.Timer(500, bs.WeakCall(self.shieldDecay), repeat=True)
            self.shield.alwaysShowHealthBar = True
        def changeColor():
            if self.shield is None: return
            if bs.getConfig()["colorsMod"]["shieldColor"]:
                self.shield.color = (random.random(),random.random(),random.random())
        self._colorTimer = bs.gameTimer(bs.getConfig()["colorsMod"]["timeDelay"],bs.Call(changeColor),repeat=True)
PlayerSpaz.equipShields = equipNewShields

oldBlastInit = Blast.__init__
def newBlastInit(self, *args, **kwargs):
    oldBlastInit(self, *args, **kwargs)
    if bs.getConfig()["colorsMod"]["xplotionColor"]:
        scorchRadius = self.radius
        s = bs.newNode('scorch',attrs={'position':self.node.position, 'size':scorchRadius*0.5,'big':(self.blastType == 'tnt')})
        s2 = bs.newNode('scorch',attrs={'position':self.node.position, 'size':scorchRadius*0.5,'big':(self.blastType == 'tnt')})
        s3 = bs.newNode('scorch',attrs={'position':self.node.position,'size':scorchRadius*0.5,'big':(self.blastType == 'tnt')})
        if self.blastType == 'ice': s.color = s2.color = s3.color =(1,1,1.5)
        else: s.color = s2.color = s3.color = (random.random(),random.random(),random.random())
        if bs.getConfig()["colorsMod"]["xplotionColor"]:
            if bs.getConfig()["colorsMod"]["delScorch"]:
                bsUtils.animate(s,"presence",{3000:1, 13000:0})
                bsUtils.animate(s2,"presence",{3000:1, 13000:0})
                bs.gameTimer(13000,s.delete)
                bs.gameTimer(13000,s2.delete)
Blast.__init__ = newBlastInit

oldFlagInit = Flag.__init__
def newFlaginit(self, position=(0, 1, 0),color=(1, 1, 1),materials=[],touchable=True, droppedTimeout=None):
    oldFlagInit( self, position=position, color=color,materials=materials,touchable=touchable, droppedTimeout=droppedTimeout)	
    
    def cC():
        if self.node.exists():
            if bs.getConfig()["colorsMod"]["flag"]:
                self.node.color = (random.random()*1.2,random.random()*1.2,random.random()*1.2)
        else: return
    if touchable : bs.gameTimer(bs.getConfig()["colorsMod"]["timeDelay"],bs.Call(cC),repeat=True)	
Flag.__init__ = newFlaginit

oldWindowInit = PlayerProfilesWindow.__init__
def newWindowInit(self, *args, **kwargs):
    oldWindowInit(self, *args, **kwargs)
    width = 700 if gSmallUI else 600
    xInset = 50 if gSmallUI else 0
    height = 360 if gSmallUI else 385 if gMedUI else 410
	
    def doColorMenu():
        bs.containerWidget(edit=self._rootWidget,transition=self._transitionOut)
        ColorsMenu()
		
    self._adventureModeButton = bs.buttonWidget(parent=self._rootWidget, autoSelect=True,
                                            position=((width*0.98)-150, self._height - 55), size=(125,50),
                                            scale=0.8, textScale=1.2,textColor=(1,1,1),
                                            label="Colors Mod", onActivateCall=doColorMenu)
											
PlayerProfilesWindow.__init__ = newWindowInit

class ColorsMenu(PopupWindow):

    def __init__(self,transition='inRight'):
        self._width = width = 600
        self._height = height = 420

        self._scrollWidth = self._width*0.90
        self._scrollHeight = self._height - 180
        self._subWidth = self._scrollWidth*0.95;
        self._subHeight = 200
		
        self._current_tab = bs.getConfig()['colorsMod']['tab']
        self._timeDelay =  bs.getConfig()["colorsMod"]["timeDelay"]
        self._glowScale =  bs.getConfig()["colorsMod"]["glowScale"]
		
        txtFinal = "Ajustes de Colors Mod" if bs.getLanguage() == "Spanish" else "Colors Mod Settings"
		
        if bs.getLanguage() == "Spanish":
            self._credits = ("Modifica y aplica efectos\n"
           	                "a los colores de tu personaje,\n"
           	                "explosiones, bots, escudos,\n"
                            "entre otras cosas...\n\n"
                            "Programado por RACKER\nTraducido por BROODY")
            self._warn = ("ADVERTENCIA\nEste mod puede ocacionar\nefectos de epilepsia\na personas sensibles.")
        else:
            self._credits = ("Modify and add effects\n" #-Ingles por favor -Hecho!! :D
           	                "to your character colours.\n"
                            "And other stuff...\n\n"
                            "Mod made by RACKER\nTranslated by BROODY")
            self._warn = ("WARNING\nThis mod is MODIFIED by BROODY\nOpen source Mod\nHope u will enjoy")

        self._rootWidget = bs.containerWidget(size=(width,height),transition=transition,
                                              scale=2.0 if gSmallUI else 1.4 if gMedUI else 1.0,
                                              stackOffset=(0,-30) if gSmallUI else (0,0))
        
        self._backButton = b = bs.buttonWidget(parent=self._rootWidget,autoSelect=True,position=(60,self._height-75),size=(130,60),scale=0.8,textScale=1.2,
                            label=bs.Lstr(resource='backText'),buttonType='back',onActivateCall=self._back)	
        if gDoAndroidNav:
            bs.buttonWidget(edit=self._backButton,buttonType='backSmall',size=(60,60),label=bs.getSpecialChar('back'))
                                               
        bs.containerWidget(edit=self._rootWidget,cancelButton=b)
        t = bs.textWidget(parent=self._rootWidget,position=(0,height-55),size=(width,50),
                          text=txtFinal,
                          hAlign="center",color=gTitleColor,
                          vAlign="center",maxWidth=width*0.5)
												
        v = self._subHeight - 55
        v0 = height - 90
     			
        tabs = [['color',"Colores" if bs.getLanguage() == "Spanish" else "Colors"],
                ['glow',"Brillo" if bs.getLanguage() == "Spanish" else "Glow"],
                ['extra',"Extras" if bs.getLanguage() == "Spanish" else "Extras"],
               ]
			   
        tabs2 = [['general',"General" if bs.getLanguage() == "Spanish" else "General"],
                ['info',"Info" if bs.getLanguage() == "Spanish" else "Info"],
               ]
			   
        self._tab_buttons2 = bsUI._createTabButtons(
            self._rootWidget, tabs2,
            pos=(self._width*0.22,85+self._scrollHeight), 
            size=(self._scrollWidth*0.62,20),
            onSelectCall=self._setTab)
			   
        self._tab_buttons = bsUI._createTabButtons(
            self._rootWidget, tabs,
            pos=(self._width*0.08,45+self._scrollHeight), 
            size=(self._scrollWidth*0.93,30),
            onSelectCall=self._setTab)	
			
        self._scrollWidget = bs.scrollWidget(parent=self._rootWidget,size=(self._subWidth,self._scrollHeight),
                                             highlight=False, position=(self._width*0.08,51),captureArrows=True)
        self._tabContainer = None
        self._setTab(self._current_tab)
		
    def _setTab(self,tab):
        self._colorTimer = None
        self._current_tab = tab
        bs.getConfig()['colorsMod']['tab'] = tab
        bs.writeConfig()
        bsUI._updateTabButtonColors(self._tab_buttons, tab)
        bsUI._updateTabButtonColors(self._tab_buttons2, tab)
        if self._tabContainer is not None and self._tabContainer.exists():
            self._tabContainer.delete()
        self._tabData = {}

		
        if tab == 'info':
            subHeight = 420
            self._tabContainer = c = bs.containerWidget(parent=self._scrollWidget,size=(self._subWidth,subHeight),
                                                background=False,selectionLoopToParent=True)
            bs.widget(edit=c, upWidget=self._tab_buttons2[tab])
            v = subHeight - 55
            cWidth = self._scrollWidth
            cHeight = min(self._scrollHeight, 200*1.0+100)
            
            self._timeDelayText = bs.textWidget(
                parent=c, position=(0,v),
                color=(0.1, 1.0, 0.1),
                scale=1.2, size=(self._subWidth, 0),
                maxWidth=cWidth * 0.9, maxHeight=cHeight * 0.9, hAlign='center',
                vAlign='center', text='COLORS MOD')			
            v -= 130
            t = bs.textWidget(
                parent=c, position=(0, v),
                color=(0.8, 0.8, 0.8),
                scale=0.8, size=(self._subWidth*0.95, 0),
                maxWidth=cWidth * 0.9, maxHeight=cHeight * 0.9, hAlign='center',
                vAlign='center', text=self._credits)
            v -= 165
            t = bs.textWidget(
                parent=c, position=(0, v),
                color=(2,0,0),
                scale=0.8, size=(self._subWidth*0.95, 0),
                maxWidth=cWidth * 0.9, maxHeight=cHeight * 0.9, hAlign='center',
                vAlign='center', text=self._warn)
            self._updateColorTimer()

        elif tab == 'general':
            subHeight = 200
            self._tabContainer = c = bs.containerWidget(parent=self._scrollWidget,size=(self._subWidth,subHeight),
                                                background=False,selectionLoopToParent=True)
            v = subHeight - 50
			
            t = bs.textWidget(parent=c,position=(0,v),
                          text="Brillo de colores" if bs.getLanguage() == "Spanish" else "Colors glow scale",
                          maxWidth=self._scrollWidth,size=(self._scrollWidth*0.5,20),color=(0.8,0.8,0.8,1.0),hAlign="center",scale=1.0,)
						  
            b = bs.buttonWidget(parent=c,position=(self._subWidth*0.7-80,v-10),size=(30,30),label="-",
                            autoSelect=True,onActivateCall=bs.Call(self._glowScaleDecrement),repeat=True,enableSound=True,buttonType='square')
            self._glowScaleText = bs.textWidget(parent=c,position=(self._subWidth*0.5,v),maxWidth=self._scrollWidth,
                            size=(self._scrollWidth*0.4,20),editable=False,color=(0.3,1.0,0.3),hAlign="center",text=str(self._glowScale),padding=2)
            b2 = bs.buttonWidget(parent=c,position=(self._subWidth*0.7+60,v-10),size=(30,30),label="+",
                            autoSelect=True,onActivateCall=bs.Call(self._glowScaleIncrement),repeat=True,enableSound=True,buttonType='square')
							
            v -= 70
            t = bs.textWidget(parent=c,position=(0,v),
                          text="Intervalo de tiempo" if bs.getLanguage() == "Spanish" else "Time delay",
                          maxWidth=self._scrollWidth*0.9,size=(self._scrollWidth*0.5,20),color=(0.8,0.8,0.8,1.0),hAlign="center",scale=1.0,)
						  
            a = bs.buttonWidget(parent=c,position=(self._subWidth*0.7-80,v-10),size=(30,30),label="-",
                            autoSelect=True,onActivateCall=bs.Call(self._timeDelayDecrement),repeat=True,enableSound=True,buttonType='square')
            self._timeDelayText = bs.textWidget(parent=c,position=(self._subWidth*0.5,v),maxWidth=self._scrollWidth*0.9,
                            size=(self._scrollWidth*0.4,20),editable=False,color=(0.3,1.0,0.3,1.0),hAlign="center",text=str(self._timeDelay),padding=2)
            a2 = bs.buttonWidget(parent=c,position=(self._subWidth*0.7+60,v-10),size=(30,30),label="+",
                            autoSelect=True,onActivateCall=bs.Call(self._timeDelayIncrement),repeat=True,enableSound=True,buttonType='square')
							
            v -= 60
            reset = bs.buttonWidget(parent=c, autoSelect=True,
                                    position=((self._scrollWidth*0.45)-80, v-25), size=(160,50),scale=1.0, textScale=1.2,textColor=(1,1,1),
                                    label="Reiniciar" if bs.getLanguage() == "Spanish" else "Reset",onActivateCall=self._resetValues)
			
            self._updateColorTimer()
		
        elif tab == 'color':
            subHeight = 465
            self._tabContainer = c = bs.containerWidget(parent=self._scrollWidget,size=(self._subWidth,subHeight),
                                                background=False,selectionLoopToParent=True)
            v = subHeight - 40
												
            t = bs.textWidget(parent=c,position=(0,v),
                          text="Jugadores" if bs.getLanguage() == "Spanish" else "Players",
                          maxWidth=self._scrollWidth,size=(self._scrollWidth*0.95,20),color=(0.8,0.8,0.8,1.0),hAlign="center",scale=1.0,)
						  
            v -= 50
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["changeColor"],
                                      onValueChangeCall=bs.Call(self._setSetting,'changeColor'), maxWidth=self._scrollWidth*0.9,
                                      text='Color principal cambiante' if bs.getLanguage() == 'Spanish' else 'Changing Color' ,autoSelect=True)
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["changeHighlight"],
                                      onValueChangeCall=bs.Call(self._setSetting,'changeHighlight'), maxWidth=self._scrollWidth*0.9,
                                      text='Color secundario cambiante' if bs.getLanguage() == 'Spanish' else 'Changing highlight',autoSelect=True)
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["changeName"],
                                      onValueChangeCall=bs.Call(self._setSetting,'changeName'), maxWidth=self._scrollWidth*0.9,
                                      text='Color de nombre cambiante' if bs.getLanguage() == 'Spanish' else 'Changing Name Color',autoSelect=True)

            v -= 60									  
            t = bs.textWidget(parent=c,position=(0,v),
                          text="Otras cosas" if bs.getLanguage() == "Spanish" else "Other things",
                          maxWidth=self._scrollWidth,size=(self._scrollWidth*0.95,20),color=(0.8,0.8,0.8,1.0),hAlign="center",scale=1.0,)
            v -= 50
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["colorBots"],
                                      onValueChangeCall=bs.Call(self._setSetting,'colorBots'), maxWidth=self._scrollWidth*0.9,
                                      text='Cambiar colores de bots' if bs.getLanguage() == 'Spanish' else 'Change bot colors',autoSelect=True)
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["shieldColor"],
                                      onValueChangeCall=bs.Call(self._setSetting,'shieldColor'), maxWidth=self._scrollWidth*0.9,
                                      text='Color de escudo cambiante' if bs.getLanguage() == 'Spanish' else 'Changing shield color',autoSelect=True)	
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["flag"],
                                      onValueChangeCall=bs.Call(self._setSetting,'flag'), maxWidth=self._scrollWidth*0.9,
                                      text='Cambiar color de la bandera' if bs.getLanguage() == 'Spanish' else 'Change flag color',autoSelect=True)	

        elif tab == 'glow':
            subHeight = 465
            self._tabContainer = c = bs.containerWidget(parent=self._scrollWidget,size=(self._subWidth,subHeight), background=False,selectionLoopToParent=True)
            v = subHeight - 40
												
            t = bs.textWidget(parent=c,position=(0,v),
                          text="Jugadores" if bs.getLanguage() == "Spanish" else "Players",
                          maxWidth=self._scrollWidth,size=(self._scrollWidth*0.95,20),color=(0.8,0.8,0.8,1.0),hAlign="center",scale=1.0,)
            v -= 50
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["glowColor"],
                                      onValueChangeCall=bs.Call(self._setSetting,'glowColor'), maxWidth=self._scrollWidth*0.9,
                                      text='Color principal brillante' if bs.getLanguage() == 'Spanish' else 'Glowing color',autoSelect=True)					  
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["glowHighlight"],
                                      onValueChangeCall=bs.Call(self._setSetting,'glowHighlight'), maxWidth=self._scrollWidth*0.9,
                                      text='Color secundario brillante' if bs.getLanguage() == 'Spanish' else 'Glowing highlight',autoSelect=True)
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["glowName"],
                                      onValueChangeCall=bs.Call(self._setSetting,'glowName'), maxWidth=self._scrollWidth*0.9,
                                      text='Color de nombre brillante' if bs.getLanguage() == 'Spanish' else 'Glowing name color',autoSelect=True)
									  
            v -= 60									  
            t = bs.textWidget(parent=c,position=(0,v),
                          text="Otras cosas" if bs.getLanguage() == "Spanish" else "Other things",
                          maxWidth=self._scrollWidth,size=(self._scrollWidth*0.95,20),color=(0.8,0.8,0.8,1.0),hAlign="center",scale=1.0,)
						  
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["glowingBombs"],
                                      onValueChangeCall=bs.Call(self._setSetting,'glowingBombs'), maxWidth=self._scrollWidth*0.9,
                                      text='Bombas brillantes' if bs.getLanguage() == 'Spanish' else 'Glowing bombs',autoSelect=True)
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["glowBots"],
                                      onValueChangeCall=bs.Call(self._setSetting,'glowBots'), maxWidth=self._scrollWidth*0.9,
                                      text='Aplicar brillo a bots' if bs.getLanguage() == 'Spanish' else 'Apply glow to bots.',autoSelect=True)

        elif tab == 'extra':
            subHeight = 200
            self._tabContainer = c = bs.containerWidget(parent=self._scrollWidget,size=(self._subWidth,subHeight),
                                                background=False,selectionLoopToParent=True)
            v = subHeight - 55

            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["xplotionColor"],
                                      onValueChangeCall=bs.Call(self._setSetting,'xplotionColor'), maxWidth=self._scrollWidth*0.9,
                                      text='Explosiones de colores' if bs.getLanguage() == 'Spanish' else 'Coloring explosives',autoSelect=True)
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["delScorch"],
                                      onValueChangeCall=bs.Call(self._setSetting,'delScorch'), maxWidth=self._scrollWidth*0.9,
                                      text='Limpiar explosion de bomba' if bs.getLanguage() == 'Spanish' else 'Clean bomb explotions',autoSelect=True)
            v -= 60
            self.bw = bs.checkBoxWidget(parent=c,position=(self._subWidth*0.1,v), value=bs.getConfig()["colorsMod"]["colorTitle"],
                                      onValueChangeCall=bs.Call(self._setSetting,'colorTitle'), maxWidth=self._scrollWidth*0.9,
                                      text='Titulo de juego de colores' if bs.getLanguage() == 'Spanish' else 'Colored game titles',autoSelect=True)
										  

    def _setSetting(self,setting,m):
        bs.getConfig()["colorsMod"][setting] =  False if m==0 else True
        bs.writeConfig()
		
    def _timeDelayDecrement(self):
        self._timeDelay = max(50,self._timeDelay - 50)
        bs.textWidget(edit=self._timeDelayText,text=str(self._timeDelay))
        bs.getConfig()["colorsMod"]["timeDelay"] =  self._timeDelay
        bs.writeConfig()
        self._updateColorTimer()
		
    def _timeDelayIncrement(self):
        self._timeDelay = self._timeDelay + 50
        bs.textWidget(edit=self._timeDelayText,text=str(self._timeDelay))
        bs.getConfig()["colorsMod"]["timeDelay"] =  self._timeDelay
        bs.writeConfig()
        self._updateColorTimer()
		
    def _resetValues(self):
        bs.getConfig()["colorsMod"]["glowScale"] = self._glowScale =  1
        bs.getConfig()["colorsMod"]["timeDelay"] = self._timeDelay =  500
        bs.textWidget(edit=self._glowScaleText,text=str(self._glowScale))
        bs.textWidget(edit=self._timeDelayText,text=str(self._timeDelay))
        bs.writeConfig()
        self._updateColorTimer()
		
    def _updateColorTimer(self):
        self._colorTimer = bs.Timer(bs.getConfig()["colorsMod"]["timeDelay"],bs.Call(self._update),repeat=True,timeType='real')
		
    def _update(self):
        color = (random.random(),random.random(),random.random())
        bs.textWidget(edit=self._timeDelayText,color=color)
		
    def _glowScaleDecrement(self):
        self._glowScale = max(1,self._glowScale - 1)
        bs.textWidget(edit=self._glowScaleText,text=str(self._glowScale))
        bs.getConfig()["colorsMod"]["glowScale"] =  self._glowScale
        bs.writeConfig()
		
    def _glowScaleIncrement(self):
        self._glowScale = min(10,self._glowScale + 1)
        bs.textWidget(edit=self._glowScaleText,text=str(self._glowScale))
        bs.getConfig()["colorsMod"]["glowScale"] =  self._glowScale
        bs.writeConfig()

    def _back(self):
        bs.containerWidget(edit=self._rootWidget,transition='outRight')
        self._colorTimer = None
        uiGlobals['mainMenuWindow'] = PlayerProfilesWindow(transition='inLeft').getRootWidget()
		
def partyColor(self):
    bsUtils.animateArray(bs.getSharedObject('globals'),'vignetteOuter',3,
        {0:bs.getSharedObject('globals').vignetteOuter,
        bs.getConfig()["colorsMod"]["timeDelay"]:(random.random()*1.5,random.random()*1.5,random.random()*1.5)})
		
def _makeNewWord(self, word, x, y, scale=1.0, delay=0, vrDepthOffset=0, shadow=False):
        if shadow:
            wordShadowObj = bs.NodeActor(bs.newNode('text', attrs={
                'position':(x,y), 'big':True,'color':(0.0,0.0,0.2,0.08),
                'tiltTranslate':0.09,'opacityScalesShadow':False,
                'shadow':0.2, 'vrDepth':-130, 'vAlign':'center',
                'projectScale':0.97*scale, 'scale':1.0,'text':word}))
            self._wordActors.append(wordShadowObj)
        else:
            wordObj = bs.NodeActor(bs.newNode('text', attrs={'position':(x,y),'big':True,
                'color':(random.random()*1.2,random.random()*1.2,random.random()*1.2) 
                        if bs.getConfig()["colorsMod"]["colorTitle"] else (1.2,1.15,1.15,1.0),
                'tiltTranslate':0.11, 'shadow':0.2, 'vrDepth':-40+vrDepthOffset,
				'vAlign':'center','projectScale':scale, 'scale':1.0,'text':word}))
            self._wordActors.append(wordObj)
			
        if not bs.getEnvironment()['vrMode']:
            if not shadow: c = bs.newNode("combine", owner=wordObj.node, attrs={'size':2})
            else: c = None
            if shadow: c2 = bs.newNode("combine", owner=wordShadowObj.node,attrs={'size':2})
            else:c2 = None
            if not shadow:c.connectAttr('output',wordObj.node,'position')
            if shadow: c2.connectAttr('output',wordShadowObj.node,'position')
            keys = {}
            keys2 = {}
            timeV = 0
            for i in range(10):
                val = x+(random.random()-0.5)*0.8
                val2 = x+(random.random()-0.5)*0.8
                keys[timeV*self._ts] = val
                keys2[timeV*self._ts] = val2+5
                timeV += random.random() * 100
            if c is not None: bs.animate(c, "input0", keys, loop=True)
            if c2 is not None: bs.animate(c2, "input0", keys2, loop=True)
            keys = {}
            keys2 = {}
            timeV = 0
            for i in range(10):
                val = y+(random.random()-0.5)*0.8
                val2 = y+(random.random()-0.5)*0.8
                keys[timeV*self._ts] = val
                keys2[timeV*self._ts] = val2-9
                timeV += random.random() * 100
            if c is not None: bs.animate(c,"input1",keys,loop=True)
            if c2 is not None: bs.animate(c2,"input1",keys2,loop=True)

        if not shadow:bs.animate(wordObj.node, "projectScale",{delay:0.0, delay+100:scale*1.1, delay+200:scale})
        else: bs.animate(wordShadowObj.node, "projectScale",{delay:0.0, delay+100:scale*1.1, delay+200:scale})
        #self._party = bs.Timer(bs.getConfig()["colorsMod"]["timeDelay"],bs.Call(partyColor,self),repeat = True)
bsMainMenu.MainMenuActivity._makeWord = _makeNewWord